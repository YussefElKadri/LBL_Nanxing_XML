﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Xml.Linq;

namespace LeituraEscritaArquivos
{
	public class LeituraArquivosEscrita
	{
		public string LeituraEscritaTXT(string pasta)
		{
			string[] listaArquivosTXTs = Directory.GetFiles(pasta, "*.txt");
			string arquivoTemporario = Path.GetTempFileName();

			foreach (var txt in listaArquivosTXTs)
			{
				List<string> Codigo = new List<string>();
				List<decimal> Xp = new List<decimal>();
				List<decimal> Yp = new List<decimal>();
				List<decimal> Cp = new List<decimal>();
				List<decimal> Lp = new List<decimal>();
				List<string> Imagem = new List<string>();
				List<int> Ang = new List<int>();
				List<int> CuttingOrderNo = new List<int>();
				string[] leituraTotalTotal = File.ReadAllLines(txt);

				StreamReader leituraTXT = new StreamReader(txt);
				{
					for (int i = 0; i < leituraTotalTotal.Length; i++)
					{
						string valorDiametroToolSup = leituraTotalTotal[i];
						string[] tamanhoLinha = valorDiametroToolSup.Split(';');
						int Angulo = 0;


						for (int j = 0; j < tamanhoLinha.Length; j++)
						{
							if (j == 0) { Codigo.Add(tamanhoLinha[j]); }
							else if (j == 0) { Codigo.Add(tamanhoLinha[j]); }
							else if (j == 1) { Xp.Add(Convert.ToDecimal(tamanhoLinha[j])); }
							else if (j == 2) { Yp.Add(Convert.ToDecimal(tamanhoLinha[j])); }
							else if (j == 3) { Cp.Add(Convert.ToDecimal(tamanhoLinha[j])); }
							else if (j == 4) { Lp.Add(Convert.ToDecimal(tamanhoLinha[j])); }
							else if (j == 5) { Imagem.Add(tamanhoLinha[j]); }
							else if (j == 6) { Ang.Add(Convert.ToInt32(tamanhoLinha[j])); }
							else if (j == 7) { CuttingOrderNo.Add(Convert.ToInt32(tamanhoLinha[j])); }
						}

						StreamWriter escritaTXT = new StreamWriter(arquivoTemporario);
						{
							for (int k = 0; k < Codigo.Count; k++)
							{
								Angulo = Ang[k];

								escritaTXT.WriteLine(value: $"        <Workpiece ID=\"{Codigo[k]}\" WorkpieceId=\"{Codigo[k]}\" CuttingOrderNo=\"{CuttingOrderNo[k]}\" LabelImageFileName=\"{"Ardis_XML.png"}\" Qty=\"{1}\" Name=\"{Codigo[k]}\" Length=\"{Cp[k]}\" Width=\"{Lp[k]}\" CutLength=\"{Cp[k]}\" CutWidth=\"{Lp[k]}\" Thickness=\"{0}\" MachiningPoint=\"{0}\" Designer=\"{Imagem[k]}\" RotateAngle=\"{Angulo}\">");
								escritaTXT.WriteLine("          <EdgeGroup X1 = \"0\" Y1 = \"0\" >");
								escritaTXT.WriteLine("            <Edge Face=\"1\" Thickness=\"1\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
								escritaTXT.WriteLine("            <Edge Face=\"2\" Thickness=\"1\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
								escritaTXT.WriteLine("            <Edge Face=\"3\" Thickness=\"1\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
								escritaTXT.WriteLine("            <Edge Face=\"4\" Thickness=\"1\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
								escritaTXT.WriteLine("          </EdgeGroup>");
								escritaTXT.WriteLine(value: $"          <Lineament RotationAngle=\"0\" X=\"{Xp[k]}\" Y=\"{Yp[k]}\" ProOffsetX=\"5\" ProOffsetY=\"5\">");
								escritaTXT.WriteLine("            <Points>");
								escritaTXT.WriteLine(value: $"              <Point Index=\"1\" X=\"{Xp[k]}\" Y=\"{Yp[k]}\" Angle=\"0\" />");
								escritaTXT.WriteLine(value: $"              <Point Index=\"2\" X=\"{Xp[k] + Cp[k]}\" Y=\"{Yp[k]}\" Angle=\"0\" />");
								escritaTXT.WriteLine(value: $"              <Point Index=\"3\" X=\"{Xp[k] + Cp[k]}\" Y=\"{Yp[k] + Lp[k]}\" Angle=\"0\" />");
								escritaTXT.WriteLine(value: $"              <Point Index=\"4\" X=\"{Xp[k]}\" Y=\"{Yp[k] + Lp[k]}\" Angle=\"0\" />");
								escritaTXT.WriteLine(value: $"              <Point Index=\"5\" X=\"{Xp[k]}\" Y=\"{Yp[k]}\" Angle=\"0\" />");
								escritaTXT.WriteLine("            </Points>");
								escritaTXT.WriteLine("            <CutInfos SamllWorkpieceFlg=\"false\">");
								escritaTXT.WriteLine("              <CutInfo CutNo=\"1\" ToolDirection=\"0\" SlopeLen=\"70\" />");
								escritaTXT.WriteLine("            </CutInfos>");
								escritaTXT.WriteLine("          </Lineament>");
								escritaTXT.WriteLine("        </Workpiece>");
							}

							escritaTXT.WriteLine("       <Labels>");

							for (int m = 0; m < Codigo.Count; m++)
							{
								Angulo = Ang[m];

								escritaTXT.WriteLine(value: $"        <Label Index=\"{m + 1}\" WorkpieceId=\"{Codigo[m]}\" X=\"{Xp[m] + Cp[m] / 2}\" Y=\"{Yp[m] + Lp[m] / 2}\"  RotateAngle=\"{Angulo}\" />");
							}

							escritaTXT.WriteLine("       </Labels>");
						}
						escritaTXT.Close();
						escritaTXT.Dispose();
						leituraTXT.Close();
						leituraTXT.Dispose();
					}
					File.Delete(txt);
					File.Copy(arquivoTemporario, txt);
				}
			}

			return pasta;
		}
	}
}
