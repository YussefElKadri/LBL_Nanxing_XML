﻿using System;
using System.IO;
using System.Windows.Forms;

namespace LeituraEscritaArquivos
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//CHAMAR("NomeCompletoApp" ; "NomeCompletoPastaSemEspaco\*.*")

			DateTime dataatual = DateTime.Now;
			DateTime datavencimento = new DateTime(year: 2100, 12, 31, 23, 59, 00);
			int comparativodata = DateTime.Compare(dataatual, datavencimento);
			LeituraArquivosEscrita novaleitura = new LeituraArquivosEscrita();
			UnificaDados novajuncao = new UnificaDados();
			OrdemMill ajustawork = new OrdemMill();

			if (comparativodata <= 0)
			{
				if (args.Length > 0)
				{
					for (int i = 0; i < args.Length; i++)
					{
						string somentepasta = Path.GetDirectoryName(args[i]);
						novaleitura.LeituraEscritaTXT(somentepasta);
						novajuncao.UnificaTXTXML(somentepasta);
						ajustawork.UnificaTXTXMLOrdemMill(somentepasta);
					}
				}
				else if (args.Length <= 0)
				{
					string pasta = Directory.GetCurrentDirectory();
					novaleitura.LeituraEscritaTXT(pasta);
					novajuncao.UnificaTXTXML(pasta);
					ajustawork.UnificaTXTXMLOrdemMill(pasta);
				}
			}
			else
			{
				MessageBox.Show("Sem licença!\nEntrar em contato com o Desenvolvedor - TopSystem\n(43) 9 9919-2981", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
	}
}