﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace LeituraEscritaArquivos
{
	public class OrdemMill
	{
		public string UnificaTXTXMLOrdemMill(string txtxmlDirectory)
		{
			string[] xmlFiles = Directory.GetFiles(txtxmlDirectory, "*.xml");

			foreach (string xmlFile in xmlFiles)
			{
				try
				{
					XDocument xmlDoc = XDocument.Load(xmlFile);

					// Processar os Workpieces em cada Pattern
					ProcessarWorkpieces(xmlDoc);

					// Salvar as alterações no XML
					xmlDoc.Save(xmlFile);
					Console.WriteLine($"Arquivo processado e salvo: {xmlFile}");
				}
				catch (Exception ex)
				{
					Console.WriteLine($"Erro ao processar o arquivo {xmlFile}: {ex.Message}");
				}
			}

			Console.WriteLine("Processo concluído.");
			return txtxmlDirectory;
		}

		static void ProcessarWorkpieces(XDocument xmlDoc)
		{
			foreach (var pattern in xmlDoc.Descendants("Pattern"))
			{
				var workpiecesNode = pattern.Element("Workpieces");
				if (workpiecesNode == null)
				{
					Console.WriteLine("Nenhum nó <Workpieces> encontrado no Pattern.");
					continue;
				}

				// Obter todos os Workpieces
				var allWorkpieces = workpiecesNode.Elements("Workpiece").ToList();

				if (allWorkpieces.Count < 2)
				{
					Console.WriteLine("Menos de 2 Workpieces encontrados. Nenhuma ação necessária.");
					continue;
				}

				// Localizar o último Workpiece com ID começando com "999"
				var lastWorkpiece = allWorkpieces.LastOrDefault(wp => wp.Attribute("ID") != null && wp.Attribute("ID").Value.StartsWith("999"));

				if (lastWorkpiece == null)
				{
					Console.WriteLine("Nenhum Workpiece com ID começando com '999' encontrado.");
					continue;
				}

				// Obter o Mills do último Workpiece
				var millsNode = lastWorkpiece.Element("Mills");
				if (millsNode == null)
				{
					Console.WriteLine("Nenhum nó <Mills> encontrado no Workpiece com ID '999'.");
					continue;
				}

				// Localizar o penúltimo Workpiece
				var penultimateWorkpiece = allWorkpieces[allWorkpieces.Count - 2]; // Penúltimo elemento

				// Inserir o Mills antes do EdgeGroup ou Lineament
				InserirMillsNaOrdem(penultimateWorkpiece, millsNode);
				Console.WriteLine($"Mills movido do Workpiece {lastWorkpiece.Attribute("ID")?.Value} para {penultimateWorkpiece.Attribute("ID")?.Value}.");

				// Remover o Workpiece com ID começando com "999"
				ApagarWorkpiece(lastWorkpiece, workpiecesNode);
			}
		}

		static void InserirMillsNaOrdem(XElement penultimateWorkpiece, XElement millsNode)
		{
			// Localizar o EdgeGroup ou Lineament no Workpiece
			var edgeGroup = penultimateWorkpiece.Element("EdgeGroup");
			var lineament = penultimateWorkpiece.Element("Lineament");

			if (edgeGroup != null)
			{
				// Inserir Mills antes do EdgeGroup
				edgeGroup.AddBeforeSelf(millsNode);
			}
			else if (lineament != null)
			{
				// Inserir Mills antes do Lineament se EdgeGroup não existir
				lineament.AddBeforeSelf(millsNode);
			}
			else
			{
				// Adicionar Mills no final se nenhum EdgeGroup ou Lineament for encontrado
				penultimateWorkpiece.Add(millsNode);
			}
		}

		static void ApagarWorkpiece(XElement workpiece, XElement workpiecesNode)
		{
			if (workpiece != null)
			{
				workpiece.Remove();
				Console.WriteLine($"Workpiece com ID {workpiece.Attribute("ID")?.Value} removido.");
			}
		}
	}
}
