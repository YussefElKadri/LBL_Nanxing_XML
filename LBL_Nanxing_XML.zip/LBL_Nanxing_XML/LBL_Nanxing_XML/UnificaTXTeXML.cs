﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace LeituraEscritaArquivos
{
	public class UnificaDados
	{
		public string UnificaTXTXML(string txtxmlDirectory)
		{
			string[] txtFiles = Directory.GetFiles(txtxmlDirectory, "*.txt");

			foreach (string txtFile in txtFiles)
			{
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(txtFile);
				string xmlFilePath = Path.Combine(txtxmlDirectory, fileNameWithoutExtension + ".xml");

				if (File.Exists(xmlFilePath))
				{
					try
					{
						string txtContent = File.ReadAllText(txtFile);

						var rootElement = XElement.Parse("<Root>" + txtContent + "</Root>");
						var workpieceElements = rootElement.Elements("Workpiece");
						var labelElements = rootElement.Elements("Labels");

						if (!workpieceElements.Any())
						{
							Console.WriteLine($"Nenhum nó <Workpiece> encontrado no arquivo TXT: {txtFile}");
							continue;
						}

						XDocument xmlDoc = XDocument.Load(xmlFilePath);
						XElement workpiecesNode = xmlDoc.Descendants("Workpieces").FirstOrDefault();

						if (workpiecesNode != null)
						{
							foreach (var workpiece in workpieceElements.Reverse())
							{
								workpiecesNode.AddFirst(workpiece);
							}

							if (labelElements.Any())
							{
								foreach (var label in labelElements)
								{
									workpiecesNode.Add(label);
								}
							}

							xmlDoc.Save(xmlFilePath);
							Console.WriteLine($"Conteúdo do arquivo {txtFile} inserido no XML {xmlFilePath}.");
						}
						else
						{
							Console.WriteLine($"Nó <Workpieces> não encontrado no arquivo XML: {xmlFilePath}");
						}
					}
					catch (Exception ex)
					{
						Console.WriteLine($"Erro ao processar o arquivo {txtFile}: {ex.Message}");
					}
				}
				else
				{
					Console.WriteLine($"Arquivo XML correspondente não encontrado para {txtFile}");
				}
			}

			DeleteTxtFiles(txtxmlDirectory);
			ConsolidateXmlFiles(txtxmlDirectory);
			Console.WriteLine("Processo concluído.");
			return txtxmlDirectory;
		}

		static void DeleteTxtFiles(string txtDirectory)
		{
			try
			{
				string[] txtFiles = Directory.GetFiles(txtDirectory, "*.txt");
				foreach (string txtFile in txtFiles)
				{
					File.Delete(txtFile);
					Console.WriteLine($"Arquivo deletado: {txtFile}");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Erro ao apagar os arquivos TXT: {ex.Message}");
			}
		}

		static void ConsolidateXmlFiles(string xmlDirectory)
		{
			try
			{
				string[] xmlFiles = Directory.GetFiles(xmlDirectory, "*.xml");
				if (xmlFiles.Length == 0) return;

				xmlFiles = xmlFiles.OrderBy(file =>
				{
					string fileName = Path.GetFileNameWithoutExtension(file);
					string[] parts = fileName.Split(new[] { "^^" }, StringSplitOptions.None);
					return parts.Length > 1 && int.TryParse(parts[1], out int planNumber) ? planNumber : int.MaxValue;
				}).ToArray();

				string mainXmlPath = xmlFiles[0];
				XDocument mainXml = XDocument.Load(mainXmlPath);
				XElement mainPatternsNode = mainXml.Descendants("Patterns").FirstOrDefault();

				if (mainPatternsNode == null)
				{
					Console.WriteLine("Nó <Patterns> não encontrado no arquivo principal.");
					return;
				}

				int nextIndex = 1;
				foreach (var pattern in mainPatternsNode.Elements("Pattern"))
				{
					pattern.SetAttributeValue("Index", nextIndex++);
				}

				foreach (string xmlFile in xmlFiles.Skip(1))
				{
					XDocument xmlDoc = XDocument.Load(xmlFile);
					var patterns = xmlDoc.Descendants("Pattern");

					foreach (var pattern in patterns)
					{
						pattern.SetAttributeValue("Index", nextIndex++);
						mainPatternsNode.Add(pattern);
					}

					File.Delete(xmlFile);
					Console.WriteLine($"Arquivo XML apagado: {xmlFile}");
				}

				string newFileName = Path.GetFileNameWithoutExtension(mainXmlPath).Split(new[] { "^^" }, StringSplitOptions.None)[0] + ".xml";
				string newFilePath = Path.Combine(xmlDirectory, newFileName);
				mainXml.Save(mainXmlPath);
				File.Move(mainXmlPath, newFilePath);
				Console.WriteLine($"Arquivo principal consolidado e renomeado para: {newFileName}");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Erro ao consolidar os arquivos XML: {ex.Message}");
			}
		}
	}
}
	